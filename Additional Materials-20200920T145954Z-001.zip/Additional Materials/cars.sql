-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 18, 2019 at 11:14 AM
-- Server version: 8.0.12
-- PHP Version: 7.2.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mailinglist_32`
--

-- --------------------------------------------------------

--
-- Table structure for table `cars`
--

CREATE TABLE `cars` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `year` varchar(50) DEFAULT NULL,
  `make` varchar(50) DEFAULT NULL,
  `model` varchar(50) DEFAULT NULL,
  `vin` varchar(50) DEFAULT NULL,
  `odometer` int(11) DEFAULT NULL,
  `color` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `vin` (`vin`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cars`
--
ALTER TABLE `cars`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
--
-- Dumping data for table `cars`
--

INSERT INTO `cars` (`id`, `user_id`, `year`, `make`, `model`, `vin`, `odometer`, `color`) VALUES
(NULL, 1, '2001', 'Chevrolet', 'Astro', 'WAUR4AFDXCN093044', 89920, 'Goldenrod'),
(NULL, 1, '1963', 'Rambler', 'Classic', 'JN1CV6FE6CM265428', 29237, 'Pink'),
(NULL, 2, '1993', 'Dodge', 'Dakota', '2G4WS52J031339000', 88335, 'Puce'),
(NULL, 3, '1993', 'Ford', 'Bronco', 'WUAW2AFC5FN337340', 37611, 'Indigo'),
(NULL, 3, '2000', 'Toyota', 'Celica', 'SAJWA4FBXCL541391', 82954, 'Khaki'),
(NULL, 3, '1981', 'Chevrolet', 'Camaro', '1HGCR2E34FA703171', 78978, 'Aquamarine'),
(NULL, 3, '2002', 'Mitsubishi', 'Eclipse', 'WAUVFAFR1CA024030', 63865, 'Indigo'),
(NULL, 4, '2004', 'Dodge', 'Viper', 'WUARL48H54K221719', 78465, 'Aquamarine'),
(NULL, 4, '1999', 'Acura', 'CL', 'TRUB3AFK4C1899237', 96697, 'Teal'),
(NULL, 4, '2010', 'Ford', 'Ranger', '1G4GC5GG9AF739514', 1456, 'Aquamarine'),
(NULL, 6, '1996', 'Chevrolet', 'Sportvan G30', '1G6KD57Y51U916157', 5096, 'Indigo'),
(NULL, 7, '2011', 'Lexus', 'LX', '3GYFNFEY2BS660723', 52636, 'Mauv'),
(NULL, 7, '2004', 'Mazda', 'B-Series Plus', 'YV1672MK5A2554101', 19207, 'Teal'),
(NULL, 7, '2005', 'Kia', 'Optima', 'WVGAK7A99AD070901', 14245, 'Violet'),
(NULL, 7, '2003', 'Mitsubishi', 'Eclipse', '2G4GR5GX1E9154696', 55594, 'Crimson'),
(NULL, 7, '2006', 'GMC', 'Yukon XL', 'WDDGF5EB9AF965397', 20598, 'Pink'),
(NULL, NULL, '1991', 'Subaru', 'Loyale', 'SCBZK22E21C630336', 41096, 'Indigo'),
(NULL, NULL, '1993', 'Mazda', 'B-Series', 'WBAVC73518A472188', 36049, 'Turquoise'),
(NULL, NULL, '1995', 'Suzuki', 'SJ', '1GKS1AE01CR912337', 89280, 'Maroon'),
(NULL, NULL, '1997', 'BMW', '7 Series', 'KMHGH4JH5EU396084', 40895, 'Mauv');

