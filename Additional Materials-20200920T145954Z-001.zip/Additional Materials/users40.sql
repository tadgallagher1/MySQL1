-- Adminer 4.7.1 MySQL dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fname` varchar(255) NOT NULL,
  `lname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `state` varchar(2) DEFAULT NULL,
  `cars` int(11) NOT NULL,
  `opt_in_date` date NOT NULL,
  `opt_out` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `users` (`id`, `fname`, `lname`, `email`, `state`, `cars`, `opt_in_date`, `opt_out`) VALUES
(NULL,  'Nickola',  'Gemeau',  'ngemeau0@topsy.com',  'CA',  9,  '2013-04-26',  0),
(NULL,  'Syman',  'Stothard',  'sstothard1@wikia.com',  'TX',  2,  '2018-04-28',  0),
(NULL,  'Susannah',  'Lanfear',  'slanfear2@sun.com',  NULL,  4,  '2013-07-16',  0),
(NULL,  'Dorthy',  'Limpricht',  'dlimpricht3@privacy.gov.au',  'FL',  6,  '2015-12-19',  0),
(NULL,  'Jillian',  'Goggan',  'jgoggan4@ning.com',  NULL,  8,  '2014-08-07',  0),
(NULL,  'Lowrance',  'Lundie',  'llundie5@sourceforge.net',  'PA',  7,  '2010-12-16',  0),
(NULL,  'Janeta',  'Cahen',  'jcahen6@oakley.com',  'AZ',  9,  '2016-03-13',  0),
(NULL,  'Ebony',  'Greig',  'egreig7@addthis.com',  'TX',  7,  '2017-11-12',  0),
(NULL,  'Malory',  'Niblo',  'mniblo8@eventbrite.com',  'OH',  9,  '2016-08-15',  0),
(NULL,  'Annabell',  'Fortin',  'afortin9@hud.gov',  'NC',  3,  '2011-05-30',  0),
(NULL,  'Porty',  'Ferentz',  'pferentza@biblegateway.com',  'CA',  5,  '2010-10-05',  0),
(NULL,  'Nathalie',  'Cornels',  'ncornelsb@washingtonpost.com',  'CO',  3,  '2016-07-11',  1),
(NULL,  'Celle',  'Reagan',  'creaganc@shinystat.com',  'CA',  1,  '2015-01-22',  0),
(NULL,  'Harper',  'Dibner',  'hdibnerd@furl.net',  'VA',  7,  '2017-07-08',  1),
(NULL,  'Vin',  'Welland',  'vwellande@who.int',  'CA',  9,  '2020-09-16',  1),
(NULL,  'Marrissa',  'Lowdwell',  'mlowdwellf@bloglines.com',  'MD',  0,  '2011-03-10',  1),
(NULL,  'Viki',  'Heaselgrave',  'vheaselgraveg@nhs.uk',  NULL,  8,  '2018-02-04',  0),
(NULL,  'Aridatha',  'Way',  'awayh@i2i.jp',  'OK',  7,  '2012-06-08',  1),
(NULL,  'Nathanial',  'Vidgeon',  'nvidgeoni@webnode.com',  'RI',  5,  '2013-02-02',  0),
(NULL,  'Emlyn',  'Kenewell',  'ekenewellj@vistaprint.com',  'CA',  9,  '2010-05-13',  1),
(NULL,  'Nada',  'Luno',  'nluno0@elegantthemes.com',  'PA',  7,  '2014-04-02',  1),
(NULL,  'Thaine',  'Bavidge',  'tbavidge1@howstuffworks.com',  NULL,  1,  '2013-07-11',  0),
(NULL,  'Crystie',  'McEttigen',  'cmcettigen2@squidoo.com',  'CA',  9,  '2013-07-04',  1),
(NULL,  'Sayres',  'Hobson',  'shobson3@ovh.net',  'IL',  4,  '2013-12-19',  1),
(NULL,  'Reube',  'Gittoes',  'rgittoes4@home.pl',  'AR',  3,  '2017-01-02',  0),
(NULL,  'Kaleb',  'Kay',  'kkay5@huffingtonpost.com',  'CA',  10,  '2016-11-20',  1),
(NULL,  'Radcliffe',  'Spirit',  'rspirit6@i2i.jp',  'AL',  7,  '2015-12-06',  1),
(NULL,  'Cart',  'Clapson',  'cclapson7@un.org',  'CA',  10,  '2018-07-26',  1),
(NULL,  'Mellisent',  'Martinat',  'mmartinat8@vistaprint.com',  'FL',  1,  '2020-04-05',  1),
(NULL,  'Elisabet',  'Gunther',  'egunther9@sina.com.cn',  'TX',  4,  '2011-07-23',  1),
(NULL,  'Peder',  'Droogan',  'pdroogana@xinhuanet.com',  'TN',  6,  '2010-08-23',  0),
(NULL,  'Janifer',  'Tendahl',  'jtendahlb@google.de',  'AL',  9,  '2019-08-07',  1),
(NULL,  'Vidovik',  'McGee',  'vmcgeec@tamu.edu',  'CA',  6,  '2017-09-09',  1),
(NULL,  'Cleveland',  'MacCambridge',  'cmaccambridged@dailymotion.com',  'OH',  8,  '2019-03-17',  1),
(NULL,  'Wiley',  'Stather',  'wstathere@elegantthemes.com',  NULL,  0,  '2020-07-20',  1),
(NULL,  'Tracey',  'McSporon',  'tmcsporonf@bloomberg.com',  'GA',  7,  '2019-08-03',  0),
(NULL,  'Lulita',  'Sinnock',  'lsinnockg@paypal.com',  'FL',  1,  '2012-04-29',  0),
(NULL,  'Shawn',  'Sancto',  'ssanctoh@rambler.ru',  'CA',  0,  '2014-04-03',  0),
(NULL,  'Putnam',  'Jukes',  'pjukesi@alibaba.com',  'VA',  10,  '2010-03-05',  0),
(NULL,  'Steve',  'Lias',  'sliasj@washington.edu',  'TX',  8,  '2011-08-16',  0);

-- 2019-07-17 11:49:07